//
//  MYAppDelegate.h
//  UISliderDemo
//
//  Created by Young on 13-12-10.
//  Copyright (c) 2013年 Young. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
