//
//  MYAppDelegate.m
//  UITextFieldDemo
//
//  Created by Young on 13-12-12.
//  Copyright (c) 2013年 Young. All rights reserved.
//

#import "MYAppDelegate.h"

@implementation MYAppDelegate
{
    UITextField *_textField;
    UIButton *_btn;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    
    _textField = [[UITextField alloc] init];
    _textField.frame = CGRectMake(10, 30, 300, 100);
    _textField.borderStyle = UITextBorderStyleBezel;
//    textField.backgroundColor = [UIColor blueColor];
    // 默认显示文字
//    textField.placeholder = @"Please input your password";
    // 密文输入
//    textField.secureTextEntry = YES;
    // 键盘样式
//    textField.keyboardType = UIKeyboardTypeNumberPad;
    // 键盘风格
//    textField.keyboardAppearance = UIKeyboardAppearanceDark;
    // 设置弹出视图
//    UIImageView *imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Marvell.jpg"]];
//    imgView.frame = CGRectMake(0, 100, 320, 100);
//    textField.inputView = imgView;
    // 设置左视图
//    UIView *leftView = [[UIView alloc] init];
//    leftView.backgroundColor = [UIColor orangeColor];
//    leftView.frame = CGRectMake(0, 0, 100, 100);
//    textField.leftView = leftView;
//    textField.leftViewMode = UITextFieldViewModeAlways;
    // 设置清楚按钮模式
    _textField.clearButtonMode = UITextFieldViewModeAlways;
    
    // 点其它TextField后再次编辑，清空原有内容
    _textField.clearsOnBeginEditing = YES;
    // 内容纵向对齐方式
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    // 文字对齐方式
    _textField.textAlignment = NSTextAlignmentCenter;
    // 设置滚动
    _textField.adjustsFontSizeToFitWidth = YES;
    // 设置首字母是否大写
    _textField.autocapitalizationType = UITextAutocorrectionTypeYes;
    // 设置return按键
    _textField.returnKeyType = UIReturnKeyGoogle;
    // 设置代理
    _textField.delegate = self;
    [self.window addSubview:_textField];
    
    // 点击屏幕任何位置，收起键盘
    UIControl *control = [[UIControl alloc] init];
    control.frame = CGRectMake(0, 0, 320, 480);
    [control addTarget:self action:@selector(controlClick) forControlEvents:UIControlEventTouchUpInside];
    [self.window addSubview:control];
    // 让control置于最下层
    [self.window sendSubviewToBack:control];
    
    // 关于键盘弹出和收起的通知
    _btn = [[UIButton alloc] init];
    _btn.backgroundColor = [UIColor blueColor];
    _btn.frame = CGRectMake(10, 400, 300, 30);
    [_btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [_btn setTitle:@"Login" forState:UIControlStateNormal];
    [self.window addSubview:_btn];
    // 订阅键盘升起的系统通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow) name:UIKeyboardWillShowNotification object:nil];
    // 订阅键盘收起的系统通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide) name:UIKeyboardWillHideNotification object:nil];
    
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)btnClick
{
    NSLog(@"Login");
}

- (void)keyboardWillShow
{
    [UIView animateWithDuration:0.25 animations:^{
        _btn.frame = CGRectMake(10, 220, 300, 30);
    } completion:^(BOOL finished) {
    }];
}

- (void)keyboardWillHide
{
    [UIView animateWithDuration:0.25 animations:^{
        _btn.frame = CGRectMake(10, 400, 300, 30);
    } completion:^(BOOL finished) {
    }];
}

- (void)controlClick
{
    [_textField resignFirstResponder];
}

// 是否可以进入编辑模式
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

// 进入编辑模式
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    NSLog(@"enter editing mode");
}

// 退出编辑模式（进入其它TextField）
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSLog(@"quit editing mode");
}

// 是否可以点击return按键
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    // 取消第一响应者
    [textField resignFirstResponder];
    NSLog(@"keyboard quit");
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
