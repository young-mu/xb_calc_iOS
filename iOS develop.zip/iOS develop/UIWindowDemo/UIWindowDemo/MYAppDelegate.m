//
//  MYAppDelegate.m
//  UIWindowDemo
//
//  Created by Young on 13-12-12.
//  Copyright (c) 2013年 Young. All rights reserved.
//

#import "MYAppDelegate.h"

@implementation MYAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    UIWindow *window1 = [[UIWindow alloc] init];
    window1.frame = CGRectMake(0, 0, 320, 300);
    window1.backgroundColor = [UIColor blueColor];
    // UIWindow默认为隐藏设置（iOS7中不好使）
    window1.hidden = NO;
    
    UIWindow *window2 = [[UIWindow alloc] init];
    window2.frame = CGRectMake(0, 0, 320, 200);
    window2.backgroundColor = [UIColor redColor];
    window2.hidden = NO;
    // 设置级别（StatusBar可盖住状态栏）
    window2.windowLevel = UIWindowLevelStatusBar;
    
    UIWindow *window3 = [[UIWindow alloc] init];
    window3.frame = CGRectMake(0, 0, 320, 100);
    window3.backgroundColor = [UIColor purpleColor];
    window3.hidden = NO;
    // 设置级别（Alert为最高级别UIWindow）
    window3.windowLevel = UIWindowLevelAlert;
    
    NSLog(@"window1level %f", window1.windowLevel);     // Normal       0
    NSLog(@"window2level %f", window2.windowLevel);     // StatusBar    1000
    NSLog(@"window3level %f", window3.windowLevel);     // Alert        2000
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
