//
//  main.m
//  HelloWorld
//
//  Created by Young on 13-12-8.
//  Copyright (c) 2013年 Young. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MYAppDelegate class]));
    }
}
