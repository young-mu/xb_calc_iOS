//
//  MYViewController.m
//  UIViewControllerDemo
//
//  Created by Young on 13-12-12.
//  Copyright (c) 2013年 Young. All rights reserved.
//

#import "MYViewController.h"
#import "SubViewController.h"

@interface MYViewController ()

@end

@implementation MYViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor orangeColor];
    NSLog(@"x = %f", self.view.frame.origin.x);
    NSLog(@"y = %f", self.view.frame.origin.y);
    NSLog(@"w = %f", self.view.frame.size.width);
    NSLog(@"h = %f", self.view.frame.size.height);
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(10, 30, 300, 30);
    btn.backgroundColor = [UIColor whiteColor];
    [btn setTitle:@"模式对话窗体转换" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)btnClick
{
    SubViewController *svc = [[SubViewController alloc] init];
    svc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController:svc animated:YES completion:^{}];
}

- (void)loadView
{
    [super loadView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"MainViewController - viewWillAppear");
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSLog(@"MainViewController - viewDidAppear");
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    NSLog(@"MainViewController - viewWillDisappear");
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    NSLog(@"MainViewController - viewDidDisappear");
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
