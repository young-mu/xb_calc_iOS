//
//  MYAppDelegate.h
//  UITextViewDemo
//
//  Created by Young on 13-12-12.
//  Copyright (c) 2013年 Young. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MYAppDelegate : UIResponder <UIApplicationDelegate, UITextViewDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
